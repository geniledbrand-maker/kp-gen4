/**
 * Основной модуль приложения
 */

document.addEventListener('DOMContentLoaded', () => {
    const bulkArea = document.getElementById('bulkArea');
    if (bulkArea && !bulkArea.style.display) {
        bulkArea.style.display = 'none';
    }
});

const SESSID = document.querySelector('[name="sessid"]')?.value || '';
const ALLOWED_PRICE_OPTIONS = window.ALLOWED_PRICE_OPTIONS || [];

let products = [];
let counter = 0;

/**
 * Инициализация приложения
 */
document.addEventListener('DOMContentLoaded', () => {
    initEventListeners();
});

/**
 * Инициализация обработчиков событий
 */
function initEventListeners() {
    const articleInput = document.getElementById('articleInput');
    if (articleInput) {
        articleInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                addProduct();
            }
        });
    }

    document.addEventListener('click', (e) => {
        const bulkArea = document.getElementById('bulkArea');
        const bulkBtn = document.querySelector('[onclick^="toggleBulkAdd"]');

        if (bulkArea && bulkArea.style.display === 'block') {
            if (!bulkArea.contains(e.target) && !bulkBtn.contains(e.target)) {
                bulkArea.style.display = 'none';
            }
        }
    });
}

/**
 * Переключает блок массового добавления
 */
function toggleBulkAdd(e) {
    if (e) e.stopPropagation();

    const area = document.getElementById('bulkArea');
    if (!area) return;

    area.style.display = (area.style.display === 'block') ? 'none' : 'block';
}

/**
 * Вспомогательные функции
 */
function toast(msg, isError = false) {
    const toastEl = document.getElementById('toast');
    if (!toastEl) return;

    toastEl.textContent = msg;
    toastEl.className = 'toast' + (isError ? ' error' : '');
    toastEl.style.display = 'block';

    setTimeout(() => {
        toastEl.style.display = 'none';
    }, 2500);
}

function money(value, currency = 'RUB') {
    const num = Number(value) || 0;
    const formatted = num.toLocaleString('ru-RU', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
    const symbol = currency === 'RUB' ? '₽' : currency;
    return formatted + '\u00A0' + symbol;
}

async function post(action, payload) {
    const body = new URLSearchParams({
        action,
        sessid: SESSID,
        ...payload
    });

    const response = await fetch('', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body
    });

    return await response.json();
}

/**
 * Построение данных КП для отправки
 */
function buildKpInfo() {
    const dateField = document.getElementById('kpDate');
    const date = dateField && dateField.value ? new Date(dateField.value) : new Date();

    return {
        date: date.toLocaleDateString('ru-RU'),
        customer: fieldValue('customerName'),
        object: fieldValue('objectName'),
        manager: fieldValue('managerName'),
        position: fieldValue('managerPosition'),
        phone: fieldValue('managerPhone'),
        email: fieldValue('managerEmail'),
        company: fieldValue('managerCompany'),
        comment: fieldValue('comment')
    };
}

function fieldValue(id) {
    const field = document.getElementById(id);
    return field ? field.value.trim() : '';
}

/**
 * Заполнение тестовыми данными
 */
function fillTestData() {
    const today = new Date();
    const fields = {
        'kpDate': today.toISOString().split('T')[0],
        'customerName': 'ООО "Рога и копыта"',
        'objectName': 'Москва, ул. Ленина, д. 15, офис 301',
        'managerName': 'Иванов Иван Иванович',
        'managerPosition': 'Координатор отдела продаж',
        'managerEmail': 'ivanov@rogaikopyta.ru',
        'managerPhone': '+7 (495) 123-45-67',
        'managerCompany': 'ООО ИнПродакшн',
        'comment': 'Срок поставки: 14 рабочих дней. Гарантия: 3 года. Монтаж обсуждается отдельно.'
    };

    for (const [id, value] of Object.entries(fields)) {
        const el = document.getElementById(id);
        if (el) {
            el.value = value;
        }
    }

    toast('Тестовые данные заполнены');
}

/**
 * Очистка всех товаров
 */
function clearAll() {
    if (confirm('Очистить таблицу товаров?')) {
        products = [];
        render();
        toast('Таблица очищена');

        // ✅ Обновляем отметки после очистки
        if (typeof window.markAddedInLiveSearch === 'function') {
            window.markAddedInLiveSearch();
        }
    }
}

/**
 * Экспорт в Excel
 */
function exportExcel() {
    if (products.length === 0) {
        toast('Добавьте товары для экспорта', true);
        return;
    }

    postForm('export_excel', {
        products: JSON.stringify(products),
        kp_info: JSON.stringify(buildKpInfo())
    });

    toast('Генерация Excel…');
}

/**
 * Экспорт в PDF
 */
function exportPdf() {
    if (products.length === 0) {
        toast('Добавьте товары для экспорта', true);
        return;
    }

    postForm('export_pdf', {
        products: JSON.stringify(products),
        kp_info: JSON.stringify(buildKpInfo())
    });

    toast('Генерация PDF…');
}

/**
 * Отправка формы в новом окне
 */
function postForm(action, payload) {
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '';
    form.target = '_blank';

    const actionInput = document.createElement('input');
    actionInput.type = 'hidden';
    actionInput.name = 'action';
    actionInput.value = action;
    form.appendChild(actionInput);

    const sessidInput = document.createElement('input');
    sessidInput.type = 'hidden';
    sessidInput.name = 'sessid';
    sessidInput.value = SESSID;
    form.appendChild(sessidInput);

    for (const [key, value] of Object.entries(payload)) {
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = key;
        input.value = typeof value === 'string' ? value : JSON.stringify(value);
        form.appendChild(input);
    }

    document.body.appendChild(form);
    form.submit();
    document.body.removeChild(form);
}

/**
 * Добавление товара из живого поиска (исправленная версия)
 */
function addProductFromSearch(article) {
    if (!article) {
        toast('Пустой артикул', true);
        return;
    }

    if (typeof addProductByArticle === 'function') {
        addProductByArticle(article, 1, false);
    } else {
        console.error('Функция addProductByArticle() не найдена');
        toast('Ошибка: addProductByArticle() не найдена', true);
    }
}

/**
 * Обновляет отметку "✅ уже в КП" в живом поиске (улучшенная версия)
 */
window.markAddedInLiveSearch = function() {
    try {
        const box = document.getElementById('liveSearchResults');
        if (!box || box.style.display === 'none') return;

        const buttons = box.querySelectorAll('.btn-add-product');

        buttons.forEach(btn => {
            const article = btn.getAttribute('data-article');
            if (!article) return;

            // 🔍 Улучшенная проверка наличия товара в массиве
            const exists = products.some(p => {
                const pArticle = String(p.article || p.xml_id || p.code || '').trim();
                const searchArticle = String(article).trim();
                return pArticle === searchArticle;
            });

            if (exists) {
                btn.disabled = true;
                btn.textContent = '✅ В КП';
                btn.classList.add('in-kp');
            } else {
                btn.disabled = false;
                btn.textContent = 'Добавить';
                btn.classList.remove('in-kp');
            }
        });
    } catch (e) {
        console.error('markAddedInLiveSearch error', e);
    }
};

/**
 * Показать модальное окно подтверждения
 */
function showConfirmModal(message, onConfirm) {
    const modal = document.getElementById('confirmModal');
    const messageEl = document.getElementById('confirmMessage');
    const confirmBtn = document.getElementById('confirmActionBtn');

    if (!modal) return;

    // Обновляем сообщение
    if (messageEl) {
        messageEl.textContent = message;
    }

    // Устанавливаем обработчик подтверждения
    confirmBtn.onclick = () => {
        closeConfirmModal();
        if (typeof onConfirm === 'function') {
            onConfirm();
        }
    };

    // Показываем модалку
    modal.classList.add('show');
}

/**
 * Закрыть модальное окно подтверждения
 */
function closeConfirmModal() {
    const modal = document.getElementById('confirmModal');
    if (modal) {
        modal.classList.remove('show');
    }
}

/**
 * Показать модальное окно результата смены цен
 */
function showPriceChangeModal(priceTypeName) {
    const modal = document.getElementById('priceChangeModal');
    if (!modal) return;

    const message = modal.querySelector('.modal-message');

    // Обновляем сообщение
    if (message) {
        if (priceTypeName) {
            message.textContent = `Применён тип цен: ${priceTypeName}`;
        } else {
            message.textContent = 'Цены для всех товаров обновлены';
        }
    }

    // Показываем модалку
    modal.classList.add('show');

    // Автоматически скрываем через 3 секунды
    setTimeout(() => {
        modal.classList.remove('show');
    }, 3000);
}

/**
 * Глобальная функция для переключения селекта (вызывается из HTML)
 */
function toggleGlobalPriceSelect(button) {
    const wrapper = button.closest('.custom-select');
    if (!wrapper) return;

    const isOpen = wrapper.classList.contains('open');

    // Закрываем все другие селекты
    document.querySelectorAll('.custom-select.open').forEach(s => {
        if (s !== wrapper) {
            s.classList.remove('open');
        }
    });

    // Переключаем текущий
    wrapper.classList.toggle('open');
}

/**
 * Выбор типа цены из глобального селекта (вызывается из HTML)
 */
function selectGlobalPriceType(item) {
    const priceTypeId = item.getAttribute('data-value');
    const priceTypeName = item.textContent;

    if (!priceTypeId) return;

    // Обновляем нативный select
    const nativeSelect = document.getElementById('globalPriceTypeSelect');
    if (nativeSelect) {
        nativeSelect.value = priceTypeId;
    }

    // Обновляем текст кнопки
    const button = item.closest('.custom-select').querySelector('.custom-select__button');
    if (button) {
        button.textContent = priceTypeName;
    }

    // Закрываем список
    const wrapper = item.closest('.custom-select');
    if (wrapper) {
        wrapper.classList.remove('open');
    }

    // Применяем тип цены ко всем товарам
    changeAllPriceTypes(priceTypeId);
}
// === Сохранение КП (отдельно, без оформления заказа) ===
async function saveKp() {
    if (!Array.isArray(products) || products.length === 0) {
        toast('Добавьте товары в таблицу', true);
        return;
    }

    // собираем данные
    const kpInfo = buildKpInfo();
    const total = products.reduce((s, p) => s + ((+p.price || 0) * (+p.quantity || 1)), 0);

    // компактная версия товаров для хранения
    const items = products.map(p => ({
        id: p.id,
        article: p.article || p.xml_id || p.code || '',
        name: p.name,
        measure: p.measure || 'шт',
        quantity: +p.quantity || 1,
        price: +p.price || 0,
        price_type_id: +p.price_type_id || null,
        discount_percent: p.discount_percent ?? null,
        currency: p.currency || 'RUB',
        image: p.image || null,
        url: p.url || null,
    }));

    const payload = {
        kp_info: kpInfo,
        items,
        total,
        currency: products?.[0]?.currency || 'RUB',
        created_at: new Date().toISOString(),
    };

    try {
        const res = await post('save_kp', { data: JSON.stringify(payload) });
        if (res?.success) {
            toast('КП сохранено');
            // можно сразу перейти в список сохранённых
            // window.location.href = res.url || '/personal/kp/';
        } else {
            toast(res?.error || 'Не удалось сохранить КП', true);
        }
    } catch (e) {
        console.error(e);
        toast('Ошибка сети при сохранении', true);
    }
}

// открыть список моих КП
function showSavedKpList() {
    window.location.href = '/personal/kp/';
}
/**
 * Управление товарами
 */

/**
 * Добавление товара по артикулу (без поля ввода)
 */
async function addProductByArticle(article, qty = 1, forceSeparate = false) {
    const art = String(article || '').trim();
    if (!art) {
        toast('Введите артикул', true);
        return;
    }

    try {
        const res = await post('get_product', { article: art });

        if (res.success && res.data) {
            applyProduct(res.data, qty, forceSeparate);
            render();
            toast('Товар добавлен');

            setTimeout(() => {
                if (typeof window.markAddedInLiveSearch === 'function') {
                    window.markAddedInLiveSearch();
                }
            }, 250);

            await refreshGlobalPriceTypes();

        } else {
            toast(res.error || 'Товар не найден', true);
        }
    } catch (e) {
        console.error(e);
        toast('Ошибка сети', true);
    }
}

/**
 * Добавление товара по артикулу
 */
async function addProduct() {
    const articleInput = document.getElementById('articleInput');
    if (!articleInput) {
        toast('Используйте подбор из списка выше', true);
        return;
    }

    const article = articleInput.value.trim();
    if (!article) {
        toast('Введите артикул', true);
        return;
    }

    await addProductByArticle(article, 1, false);
    articleInput.value = '';
}

/**
 * Массовое добавление товаров
 */
async function addMultiple() {
    const textarea = document.getElementById('bulkTextarea');
    const separateCheckbox = document.getElementById('addAsSeparate');
    if (!textarea) return;

    const forceSeparate = separateCheckbox ? separateCheckbox.checked : false;
    const { items, errors } = parseBulkInput(textarea.value);

    if (!items.length) {
        toast(errors.length ? 'Не удалось разобрать список' : 'Список пуст', true);
        return;
    }

    let added = 0;
    const issues = [...errors];

    for (const item of items) {
        try {
            const res = await post('get_product', { article: item.article });

            if (res.success && res.data) {
                applyProduct(res.data, item.quantity, forceSeparate);
                added++;
            } else {
                issues.push({ line: item.article, value: res.error || 'Нет данных' });
            }
        } catch (error) {
            issues.push({ line: item.article, value: error.message });
        }
    }

    if (added > 0) {
        render();
        toast(`Добавлено позиций: ${added}`);
        setTimeout(() => window.markAddedInLiveSearch?.(), 250);
        await refreshGlobalPriceTypes();
    }

    if (issues.length) {
        console.warn('bulk add issues', issues);
        toast(`Не обработано: ${issues.length}`, true);
    }
}

/**
 * Парсинг списка артикулов
 */
function parseBulkInput(text) {
    const items = [];
    const errors = [];
    const lines = text.split(/[\n\r]+/).map(s => s.trim()).filter(Boolean);

    for (const line of lines) {
        let article = line;
        let quantity = 1;
        const match = line.match(/^(.+?)[\s;x*]+(\d+)$/i);
        if (match) {
            article = match[1].trim();
            quantity = parseInt(match[2]) || 1;
        }
        if (article) items.push({ article, quantity });
        else errors.push({ line, value: 'Не удалось распознать' });
    }

    return { items, errors };
}

/**
 * Унификация параметров к виду [{ name, value }]
 * (новая функция — для стабильного рендера параметров в таблице)
 */
function normalizeProps(raw) {
    if (!raw) return [];
    // Уже правильный формат
    if (Array.isArray(raw) && raw.every(p => typeof p === 'object' && ('name' in p || 'NAME' in p))) {
        return raw.map(p => ({
            name: String(p.name ?? p.NAME ?? p.code ?? p.CODE ?? '').trim(),
            value: String(p.value ?? p.VALUE ?? p.val ?? '').trim()
        })).filter(p => p.name || p.value);
    }

    // Объект-словарь: { "Мощность": "12 Вт", "Цвет": "4000К" }
    if (typeof raw === 'object' && !Array.isArray(raw)) {
        return Object.entries(raw).map(([k, v]) => ({
            name: String(k ?? '').trim(),
            value: String((v ?? '')).trim()
        })).filter(p => p.name || p.value);
    }

    // Строка: "Мощность:12 Вт; Цвет:4000К" или "Мощность=12 Вт, Цвет=4000К"
    if (typeof raw === 'string') {
        const parts = raw.split(/[;,]\s*/).map(s => s.trim()).filter(Boolean);
        const items = [];
        for (const part of parts) {
            const m = part.match(/^(.+?)\s*[:=]\s*(.+)$/);
            if (m) items.push({ name: m[1].trim(), value: m[2].trim() });
            else items.push({ name: '', value: part });
        }
        return items;
    }

    return [];
}

/**
 * Применение товара к списку
 */
function applyProduct(data, qty = 1, forceSeparate = false) {
    const amount = Number(qty);
    const safeQty = Number.isFinite(amount) && amount > 0 ? amount : 1;

    // ✅ Нормализуем параметры один раз на входе
    const normalizedProps = normalizeProps(data.props);

    if (!forceSeparate) {
        const existing = products.find(item => item.id === data.id);
        if (existing) {
            existing.quantity = Number(existing.quantity) + safeQty;
            existing.price = Number(data.price);
            existing.currency = data.currency || existing.currency || 'RUB';
            existing.price_type_id = data.price_type_id || existing.price_type_id;
            // ✅ Берём новые props, если пришли; иначе оставляем старые
            existing.props = normalizedProps.length ? normalizedProps : (existing.props || []);
            existing.measure = data.measure || existing.measure;
            existing.image = data.image || existing.image;
            existing.url = data.url || existing.url;
            return false;
        }
    }

    products.push({
        ...data,
        article: (data.article || data.xml_id || data.code || data.ID || '').trim(),
        quantity: safeQty,
        rowId: ++counter,
        currency: data.currency || 'RUB',
        discount_percent: 0,
        // ✅ Всегда храним согласованный формат для рендера
        props: normalizedProps
    });

    console.log('✅ Добавлен товар:', (data.article || data.xml_id || data.code));
    return true;
}

/**
 * Удаление товара
 */
async function removeProduct(rowId) {
    products = products.filter(p => p.rowId !== rowId);
    render();
    toast('Товар удалён');
    setTimeout(() => window.markAddedInLiveSearch?.(), 200);
    await refreshGlobalPriceTypes();
}

/**
 * Смена типа цены товара (с автопересчётом скидки)
 * — теперь тоже считается ручным действием менеджера
 */
async function changePriceType(rowId, newPriceTypeId) {
    const product = products.find(p => p.rowId === rowId);
    if (!product) return;

    // если была ручная цена — спрашиваем подтверждение
    if (product.manual_price) {
        if (!confirm('Цена была изменена вручную. Заменить на цену из каталога?')) {
            render();
            return;
        }
    }

    try {
        const res = await post('change_price_type', {
            product_id: product.id,
            price_type: newPriceTypeId
        });

        if (res.success) {
            const newPrice = Number(res.price);
            const basePrice = Number(product.mic_price ?? product.base_price ?? newPrice);
            const discount = basePrice > 0 ? ((basePrice - newPrice) / basePrice * 100) : 0;

            product.price = newPrice;
            product.price_type_id = Number(newPriceTypeId);
            product.discount_percent = Math.max(0, Number(discount.toFixed(2)));
            product.manual_price = true; // ✅ теперь тоже считается ручным действием

            render();
            toast('Цена и скидка обновлены');
        } else {
            if (res.not_found) {
                removeUnavailablePriceType(newPriceTypeId);
                toast('Тип цены недоступен', true);
            } else {
                toast(res.error || 'Ошибка', true);
            }
        }
    } catch (e) {
        console.error(e);
        toast('Ошибка сети', true);
    }
}

/**
 * Массовое изменение типа цены
 */
async function changeAllPriceTypes(newPriceTypeId) {
    if (!newPriceTypeId || products.length === 0) {
        toast('Нет товаров для изменения', true);
        return;
    }

    const priceType = ALLOWED_PRICE_OPTIONS.find(pt => pt.id == newPriceTypeId);
    const priceTypeName = priceType ? priceType.name : 'выбранный тип';

    showConfirmModal(
        `Изменить тип цены на "${priceTypeName}" для всех ${products.length} товаров?`,
        async () => await performPriceTypeChange(newPriceTypeId, priceTypeName)
    );
}

/**
 * Выполнение смены типа цены (после подтверждения)
 */
async function performPriceTypeChange(newPriceTypeId, priceTypeName) {
    const select = document.getElementById('globalPriceTypeSelect');
    if (select) select.disabled = true;

    let changed = 0;
    let typeNotFound = false;

    for (const product of products) {
        try {
            const res = await post('change_price_type', {
                product_id: product.id,
                price_type: newPriceTypeId
            });

            if (res.success) {
                product.price = Number(res.price);
                product.price_type_id = Number(newPriceTypeId);
                delete product.manual_price;
                changed++;
            } else if (res.not_found) typeNotFound = true;
        } catch (e) {
            console.error('Ошибка при смене типа цены товара', product.id, e);
        }
    }

    if (select) select.disabled = false;

    if (typeNotFound) {
        removeUnavailablePriceType(newPriceTypeId);
        toast('Тип цены недоступен и удалён', true);
    } else if (changed > 0) {
        await render();
        showPriceChangeModal?.(priceTypeName);
    } else toast('Не удалось изменить тип цены', true);

    await refreshGlobalPriceTypes();
}

/**
 * Сброс цены на "МИЦ"
 */
async function resetPrice(rowId) {
    const product = products.find(p => p.rowId === rowId);
    if (!product) return;

    try {
        const res = await post('change_price_type', {
            product_id: product.id,
            price_type: 2 // МИЦ
        });

        if (res.success) {
            const newPrice = Number(res.price);
            const basePrice = Number(product.mic_price ?? product.base_price ?? newPrice);
            const discount = basePrice > 0 ? ((basePrice - newPrice) / basePrice * 100) : 0;

            // 🔹 Возвращаем исходные значения МИЦ
            product.price = newPrice;
            product.price_type_id = 2;
            product.discount_percent = Math.max(0, Number(discount.toFixed(2)));
            product.manual_price = false; // 🔹 Сбрасываем ручной режим

            render();
            toast('Цена МИЦ восстановлена');
        } else {
            toast(res.error || 'Ошибка восстановления цены', true);
        }
    } catch (e) {
        console.error(e);
        toast('Ошибка сети', true);
    }
}

/**
 * Изменение цены вручную
 * — пользователь вводит новое значение в поле "Цена"
 */
function changePrice(rowId, newPrice) {
    const product = products.find(p => p.rowId === rowId);
    if (!product) return;

    const val = parseFloat(newPrice) || 0;
    const micPrice = Number(product.mic_price ?? product.base_price ?? val);
    const discount = micPrice > 0 ? ((micPrice - val) / micPrice * 100) : 0;

    product.price = val;
    product.discount_percent = Math.max(0, Number(discount.toFixed(2)));
    product.manual_price = true; // ✅ Помечаем, что цена установлена вручную

    render();
}

/**
 * Изменение скидки вручную
 * — пользователь вводит % скидки, цена пересчитывается
 */
function changeDiscount(rowId, discountPercent) {
    const product = products.find(p => p.rowId === rowId);
    if (!product) return;

    const d = Math.max(0, Math.min(99, parseFloat(discountPercent) || 0));
    const basePrice = Number(product.mic_price ?? product.base_price ?? product.price);
    const newPrice = basePrice * (1 - d / 100);

    product.discount_percent = d;
    product.price = newPrice;
    product.manual_price = true; // ✅ Ручной режим активен (показываем ↻)

    render();
}

/**
 * Изменение количества
 */
function changeQuantity(rowId, newQuantity) {
    const product = products.find(p => p.rowId === rowId);
    if (!product) return;
    const qty = parseInt(newQuantity);
    product.quantity = Number.isFinite(qty) && qty > 0 ? qty : 1;
    render();
}

/**
 * Обновление глобального списка типов цен (в шапке и при добавлении товаров)
 */
async function refreshGlobalPriceTypes(mode = 'all') {
    try {
        const productIds = products.map(p => p.id);
        if (!productIds.length) return;

        const res = await post('get_available_price_types', {
            product_ids: JSON.stringify(productIds),
            mode
        });

        if (!res.success || !res.types) return;

        const selectWrap = document.getElementById('globalPriceTypeSelectWrap');
        if (!selectWrap) return;

        const ul = selectWrap.querySelector('.custom-select__list');
        const select = selectWrap.querySelector('select.custom-select__native');
        if (!ul || !select) return;

        ul.innerHTML = '';
        select.innerHTML = '<option value="">Тип цены ▼</option>';

        res.types.forEach(opt => {
            const li = document.createElement('li');
            li.className = 'custom-select__item';
            li.dataset.value = opt.id;
            li.textContent = opt.name;
            li.onclick = function () {
                selectGlobalPriceType(this);
            };
            ul.appendChild(li);

            const option = document.createElement('option');
            option.value = opt.id;
            option.textContent = opt.name;
            select.appendChild(option);
        });

        console.log('✅ Обновлены доступные типы цен:', res.types);
    } catch (e) {
        console.error('refreshGlobalPriceTypes error', e);
        toast('Ошибка сети при обновлении типов цен', true);
    }
}

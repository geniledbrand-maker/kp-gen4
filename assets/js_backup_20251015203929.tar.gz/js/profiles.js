/**
 * ============================================================
 * ЗАГРУЗКА ИЗ ПРОФИЛЯ БИТРИКС - profiles.js (Geniled KP)
 * ============================================================
 */

console.log("🔵 profiles.js загружается...");

/**
 * Универсальный POST-запрос (с обработкой ошибок JSON)
 */
async function safePost(action, payload = {}) {
    try {
        const res = await post(action, payload);
        if (typeof res !== "object") throw new Error("Ответ не JSON");
        return res;
    } catch (e) {
        console.error(`❌ Ошибка POST (${action}):`, e);
        toast("Ошибка запроса к серверу", true);
        return { success: false, error: "NETWORK_ERROR" };
    }
}

/**
 * Загрузить данные из профиля Битрикс
 */
window.loadFromBitrixProfile = async function () {
    console.log("📥 Загрузка данных из профиля Битрикс...");

    const res = await safePost("get_bitrix_profile", {});
    if (!res.success) {
        toast(res.error || "Ошибка загрузки данных из профиля Битрикс", true);
        return;
    }

    const d = res.data;
    console.log("Данные из Битрикс:", d); // Отладка

    // Заполняем поля
    setFieldValue("managerName", d.manager_name);
    setFieldValue("managerPosition", d.manager_position || ""); // Убедимся, что поле обновляется
    setFieldValue("managerPhone", d.manager_phone);
    setFieldValue("managerEmail", d.manager_email);
    setFieldValue("managerCompany", d.manager_company);

    // Сбрасываем выбранный профиль
    window.currentProfileId = 0;
    const select = document.getElementById("profileSelect");
    if (select) select.value = 0;

    toast("✅ Данные загружены из профиля Битрикс");
};

/**
 * Отладка: показать все поля пользователя Битрикс
 */
window.debugBitrixFields = async function () {
    console.log("🔍 Запрос полей пользователя Битрикс...");

    const res = await safePost("debug_user_fields", {});
    if (res.success) {
        console.log("📋 Все поля пользователя Битрикс:", res.fields);
        console.table(res.fields);
        alert("✅ Данные выведены в консоль браузера (F12)");
    } else {
        console.error("❌ Ошибка:", res.error);
        toast("Ошибка получения полей: " + res.error, true);
    }
};

// === ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ===

function setFieldValue(id, val) {
    const el = document.getElementById(id);
    if (el) el.value = val || "";
}

console.log("✅ profiles.js загружен");
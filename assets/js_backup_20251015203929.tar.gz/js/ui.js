"use strict";

/**
 * Geniled KP Generator – UI (оптимизированная мобильная версия)
 * ---------------------------------------------------------------
 * ✅ Кэширование типов цен для ускорения рендеринга
 * ✅ Оптимизация для мобильных устройств
 * ✅ Ленивая загрузка изображений
 * ✅ Debounced resize handler
 * ✅ Улучшенная производительность
 */

let __isRendering = false;
let globalClickHandlerInitialized = false;

// 🔹 Кэш типов цен для оптимизации
let priceTypesCache = new Map();
let lastCacheUpdate = 0;
const CACHE_DURATION = 5000; // 5 секунд

// 🔹 Определение мобильного устройства
function isMobile() {
    return (window.innerWidth || document.documentElement.clientWidth) <= 680;
}

/* === Утилиты === */
function escapeHtml(text) {
    if (text === null || text === undefined) return "";
    const div = document.createElement("div");
    div.textContent = String(text);
    return div.innerHTML;
}

if (typeof window.money !== "function") {
    window.money = function money(value, currency = "RUB") {
        const num = Number(value) || 0;
        const parts = num.toFixed(2).split(".");
        const intPart = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, " ");
        const frac = parts[1];
        const suffix = currency === "RUB" ? "₽" : currency;
        return `${intPart},${frac} ${suffix}`;
    };
}

/* === Mobile sticky total bar === */
window.updateMobileSticky = function updateMobileSticky(total, currency) {
    const sticky = document.getElementById("mobileSticky");
    const totalEl = document.getElementById("mobileTotal");
    if (!sticky || !totalEl) return;

    const hasRows = Array.isArray(window.products) && window.products.length > 0;

    if (isMobile() && hasRows) {
        totalEl.textContent =
            typeof money === "function" ? money(total, currency || "RUB") : String(total);
        sticky.classList.add("is-visible");
    } else {
        sticky.classList.remove("is-visible");
    }
};

/* === KP Info toggler — ГЛОБАЛЬНО === */
(function () {
    const SECTION_ID = "kpInfoSection";
    const BTN_SEL = ".toggle-kp-info";
    const LS_KEY = "kpInfoOpen";

    function getEls() {
        return {
            section: document.getElementById(SECTION_ID),
            btn: document.querySelector(BTN_SEL),
        };
    }

    function applyState(open) {
        const { section, btn } = getEls();
        if (!section || !btn) return;

        section.classList.toggle("open", open);
        section.style.display = open ? "block" : "none";
        btn.classList.toggle("active", open);

        btn.setAttribute("aria-expanded", String(open));
        btn.setAttribute("aria-controls", SECTION_ID);

        try { localStorage.setItem(LS_KEY, open ? "1" : "0"); } catch (_) {}
    }

    function toggleKpInfo(force) {
        const { section } = getEls();
        if (!section) return;

        const wantOpen =
            typeof force === "boolean" ? force : !section.classList.contains("open");

        applyState(wantOpen);
    }

    document.addEventListener("DOMContentLoaded", () => {
        const saved =
            (typeof localStorage !== "undefined" && localStorage.getItem(LS_KEY)) || "0";
        applyState(saved === "1");
    });

    window.toggleKpInfo = toggleKpInfo; // ← глобально
})();

/* === Получение типов цен с кэшированием === */
async function getProductPriceTypes(productId) {
    const now = Date.now();

    if (priceTypesCache.has(productId) && now - lastCacheUpdate < CACHE_DURATION) {
        return priceTypesCache.get(productId);
    }

    try {
        const res = await post("get_available_price_types", {
            product_ids: JSON.stringify([productId]),
            mode: "all",
        });

        if (res?.success && Array.isArray(res.types)) {
            priceTypesCache.set(productId, res.types);
            lastCacheUpdate = now;
            return res.types;
        }
    } catch (err) {
        console.error("Ошибка загрузки типов цен для товара", productId, err);
    }

    return [];
}

/* === Очистка кэша === */
function clearPriceTypesCache() {
    priceTypesCache.clear();
    lastCacheUpdate = 0;
}

/* === Пакетная загрузка типов цен === */
async function preloadPriceTypes(productIds) {
    const uniqueIds = [...new Set(productIds)];
    const uncachedIds = uniqueIds.filter((id) => !priceTypesCache.has(id));
    if (uncachedIds.length === 0) return;

    try {
        const res = await post("get_available_price_types", {
            product_ids: JSON.stringify(uncachedIds),
            mode: "any",
        });

        if (res?.success && Array.isArray(res.types)) {
            uncachedIds.forEach((id) => {
                priceTypesCache.set(id, res.types);
            });
            lastCacheUpdate = Date.now();
        }
    } catch (err) {
        console.error("Ошибка пакетной загрузки типов цен", err);
    }
}

/* === Основной рендер таблицы === */
async function render() {
    if (__isRendering) return;
    __isRendering = true;

    try {
        const tbody = document.getElementById("tbody");
        const totalCell = document.getElementById("totalCell");
        const kpWrap = document.getElementById("kpWrap");

        if (!tbody || !totalCell || !kpWrap) return;

        if (products.length === 0) {
            kpWrap.style.display = "none";
            clearPriceTypesCache();
            return;
        }

        kpWrap.style.display = "block";

        // ⚡ Пакетная предзагрузка типов цен
        const productIds = products.map((p) => p.id).filter(Boolean);
        await preloadPriceTypes(productIds);

        let html = "";
        let total = 0;
        const manualRows = [];
        const mobile = isMobile();

        for (let i = 0; i < products.length; i++) {
            const p = products[i];
            const qty = Number(p.quantity) || 1;
            const price = Number(p.price) || 0;
            const sum = qty * price;
            total += sum;

            const micPrice = Number(p.mic_price ?? p.base_price ?? 0);
            const discount =
                p.discount_percent ??
                (micPrice > 0 ? (((micPrice - price) / micPrice) * 100).toFixed(2) : 0);

            if (p.manual_price) manualRows.push(`#${i + 1} (${p.article || p.id})`);

            const imageHtml = p.image
                ? `<img src="${escapeHtml(p.image)}" alt="${escapeHtml(p.name)}" ${
                    mobile ? 'loading="lazy"' : ""
                }>`
                : '<div class="product-image-placeholder">📦</div>';

            const props = Array.isArray(p.props) ? p.props : [];
            const propsHtml =
                props.length > 0
                    ? `<div class="param-block">
                ${props
                        .map(
                            (pr) => `
                  <div class="param-row">
                    <span class="param-label">${escapeHtml(pr.name)}:</span>
                    <span class="param-value">${escapeHtml(pr.value)}</span>
                  </div>`
                        )
                        .join("")}
             </div>`
                    : "";

            const nameHtml = `<a href="${escapeHtml(
                p.url || "#"
            )}" target="_blank" class="link-to-product">${escapeHtml(p.name)}</a>`;

            const productPriceTypes = await getProductPriceTypes(p.id);

            const optionsHtml = productPriceTypes
                .map((opt) => {
                    const selected = Number(opt.id) === Number(p.price_type_id) ? "selected" : "";
                    return `<option value="${opt.id}" ${selected}>${escapeHtml(opt.name)}</option>`;
                })
                .join("");

            const selectClass = mobile
                ? "price-type-select mobile-native"
                : "price-type-select";

            const priceSelectHtml = `
        <select class="${selectClass}" data-row-id="${p.rowId}"
                onchange="changePriceType(${p.rowId}, this.value)">
          ${optionsHtml || '<option value="">Тип цены</option>'}
        </select>`;

            const priceControlsOpen = mobile ? '<div class="kp-controls">' : "";
            const priceControlsClose = mobile ? "</div>" : "";

            html += `
      <tr>
        <td data-label="№">${i + 1}</td>
        <td data-label="Фото">${imageHtml}</td>
        <td data-label="Артикул">${escapeHtml(p.article)}</td>
        <td data-label="Наименование / Параметры">
          <div class="name-wrap">${nameHtml}${propsHtml}</div>
        </td>
        <td data-label="Ед.">${escapeHtml(p.measure || "шт")}</td>
        ${priceControlsOpen}
        <td data-label="Кол-во">
          <input type="number" class="qty-input" value="${qty}" min="1"
                 onchange="changeQuantity(${p.rowId}, this.value)">
        </td>
        <td data-label="Цена">
          <div class="price-wrapper">
            <input type="number" class="price-input" value="${price.toFixed(2)}" min="0" step="0.01"
                   onchange="changePrice(${p.rowId}, this.value)">
            ${p.manual_price ? `<button class="btn-reset" onclick="resetPrice(${p.rowId})" title="Сбросить на МИЦ">↻</button>` : ""}
          </div>
          ${priceSelectHtml}
        </td>
        <td data-label="Скидка, %" class="discount-cell ${
                Number(discount) > 0 ? "has-discount" : ""
            }">
          <div class="input-affix">
            <input type="number" class="discount-input" value="${discount}" min="0" max="99" step="0.1"
                   onchange="changeDiscount(${p.rowId}, this.value)">
            <span class="affix">%</span>
          </div>
        </td>
        <td data-label="Сумма" class="sum-cell">${money(sum, p.currency)}</td>
        ${priceControlsClose}
        <td data-label="Удаление">
          <span class="delete-icon" onclick="removeProduct(${p.rowId})" tabindex="0" role="button" aria-label="Удалить товар">
            <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
              <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
            </svg>
          </span>
        </td>
      </tr>`;
        }

        document.getElementById("tbody").innerHTML = html;
        totalCell.textContent = money(total, products[0]?.currency || "RUB");

        if (manualRows.length) {
            console.log("%c🟣 Найдены товары с manual_price:", "color:#6B953F;font-weight:bold;", manualRows.join(", "));
        }

        if (typeof window.updateMobileSticky === "function") {
            window.updateMobileSticky(total, products[0]?.currency || "RUB");
        }

        if (!mobile) {
            initCustomSelects();
        }
    } finally {
        __isRendering = false;
    }
}

/* === Кастомные селекты === */
function initCustomSelects() {
    const selects = document.querySelectorAll(".price-type-select:not(.mobile-native)");

    selects.forEach((select) => {
        if (select.parentElement?.classList.contains("custom-select")) return;

        const wrapper = document.createElement("div");
        wrapper.className = "custom-select";

        const button = document.createElement("button");
        button.className = "custom-select__button";
        button.type = "button";
        button.setAttribute("aria-haspopup", "listbox");
        button.setAttribute("aria-expanded", "false");
        button.textContent =
            select.options[select.selectedIndex]?.text || "Выберите";

        const list = document.createElement("div");
        list.className = "custom-select__list";
        list.setAttribute("role", "listbox");

        Array.from(select.options).forEach((option) => {
            const item = document.createElement("div");
            item.className = "custom-select__item";
            item.setAttribute("role", "option");
            item.textContent = option.text;
            item.dataset.value = option.value;
            if (option.selected) item.setAttribute("aria-selected", "true");

            item.addEventListener("click", (e) => {
                e.stopPropagation();
                select.value = option.value;
                select.dispatchEvent(new Event("change", { bubbles: true }));
                button.textContent = option.text;
                list.querySelectorAll(".custom-select__item").forEach((i) => i.removeAttribute("aria-selected"));
                item.setAttribute("aria-selected", "true");
                wrapper.classList.remove("open");
                button.setAttribute("aria-expanded", "false");
            });

            list.appendChild(item);
        });

        button.addEventListener("click", (e) => {
            e.stopPropagation();
            const isOpen = wrapper.classList.contains("open");
            document.querySelectorAll(".custom-select.open").forEach((s) => {
                s.classList.remove("open");
                s.querySelector(".custom-select__button")?.setAttribute("aria-expanded", "false");
            });
            wrapper.classList.toggle("open");
            button.setAttribute("aria-expanded", (!isOpen).toString());
            if (!isOpen) positionDropdown(wrapper, button, list);
        });

        button.addEventListener("keydown", (e) => {
            if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                button.click();
            }
        });

        select.classList.add("custom-select__native");
        select.style.display = "none";

        select.parentNode.insertBefore(wrapper, select);
        wrapper.appendChild(button);
        wrapper.appendChild(list);
        wrapper.appendChild(select);
    });

    if (!globalClickHandlerInitialized) {
        document.addEventListener("click", (e) => {
            if (!e.target.closest(".custom-select")) {
                document.querySelectorAll(".custom-select.open").forEach((s) => {
                    s.classList.remove("open");
                    s.querySelector(".custom-select__button")?.setAttribute("aria-expanded", "false");
                });
            }
        });
        document.addEventListener("keydown", (e) => {
            if (e.key === "Escape") {
                document.querySelectorAll(".custom-select.open").forEach((s) => {
                    s.classList.remove("open");
                    s.querySelector(".custom-select__button")?.setAttribute("aria-expanded", "false");
                });
            }
        });
        globalClickHandlerInitialized = true;
    }
}

/* === Позиционирование выпадашки === */
function positionDropdown(wrapper, button, list) {
    const r = button.getBoundingClientRect();
    const vh = window.innerHeight;
    const spaceBelow = vh - r.bottom;
    const dropdownHeight = 260;

    const openDown = spaceBelow > dropdownHeight || spaceBelow > r.top;
    if (openDown) {
        list.style.top = `${r.bottom + 6}px`;
        list.style.bottom = "auto";
    } else {
        list.style.bottom = `${vh - r.top + 6}px`;
        list.style.top = "auto";
    }
    list.style.left = `${r.left}px`;
    list.style.minWidth = `${r.width}px`;
    list.style.width = "auto";
    list.style.position = "fixed";
}

/* === Debounced resize handler === */
let __resizeStickyTimer;
let __lastWidth = window.innerWidth;

window.addEventListener("resize", () => {
    clearTimeout(__resizeStickyTimer);
    __resizeStickyTimer = setTimeout(() => {
        const currentWidth = window.innerWidth;

        if (typeof window.updateMobileSticky === "function") {
            const total = Array.isArray(products)
                ? products.reduce((sum, p) => sum + ((+p.price || 0) * (+p.quantity || 1)), 0)
                : 0;
            window.updateMobileSticky(total, products?.[0]?.currency || "RUB");
        }

        const wasDesktop = __lastWidth > 680;
        const isDesktop = currentWidth > 680;

        if (wasDesktop !== isDesktop && products.length > 0) {
            console.log("📱 Переключение desktop/mobile режима, перерендер...");
            clearPriceTypesCache();
            render();
        }

        __lastWidth = currentWidth;
    }, 250);
});

/* === Экспорт для использования в других модулях === */
if (typeof window !== "undefined") {
    window.clearPriceTypesCache = clearPriceTypesCache;
    window.isMobile = isMobile;
}
